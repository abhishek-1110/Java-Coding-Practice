package TrainingClassesPractice;

public class AtoZ {
    public static void main(String[] args) {
        // small letters
        for (char i = 'a'; i <= 'z'; i++) {
            System.out.print(i + " ");
        }
    }
}
