package TrainingClassesPractice._27thJuly;

public class Demo {
    public static void main(String[] args) {
        Demo d = new Demo();
        System.out.println(d);
    }
}
